ILLUMIUM FLUX WINDOWS PROTOTYPE
================================

This is a native WinForms prototype of the Illumium Flux / Orbaratum filesystem renderer.

Behavior:
- Opens initially at the current user's home folder.
- Reads REAL Windows directories and files.
- Folders render as white orbs.
- Files render as black orbs.
- Every orb has a star.
- Star size/glow is based on the item's actual last-write age.
- Star colour follows live CPU/RAM/disk usage:
    green = <50%
    blue  = 50-79%
    red   = >=80%
- Double-click a folder orb to enter it.
- Double-click a file orb to execute it using Windows.
- Right-click provides enter/open, properties, run program, and browse.
- Browse lets the user select any Windows folder.

IMPORTANT WINDOW BEHAVIOR
=========================
The filesystem renderer is the shell-like application. It does not replace
Windows Explorer. Executed applications are intentionally launched through
Windows normally in this prototype, because forcing arbitrary third-party
Windows applications into a custom half-screen host window is not reliable
for every Win32/WPF/UWP application.

BUILD
=====
Requires Windows + .NET 8 SDK.

From this directory:
    dotnet build -c Release

For a standalone EXE:
    dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true

The resulting EXE will be under:
    bin\Release\net8.0-windows\win-x64\publish\IllumiumFlux.exe
