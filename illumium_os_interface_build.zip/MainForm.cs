using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.IO;

namespace IllumiumFlux;

public sealed class MainForm : Form
{
    readonly OrbCanvas canvas = new();
    readonly Label pathLabel = new();
    readonly Label resourceLabel = new();
    readonly Button back = new(), choose = new();
    readonly System.Windows.Forms.Timer resourceTimer = new() { Interval = 1000 };
    readonly System.Windows.Forms.Timer alertFlashTimer = new() { Interval = 350 };
    readonly Stack<string> history = new();
    string currentPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
    float cpu, ram, disk;
    bool securityVulnerability, temporaryAlert, alertFlashOn;
    Color persistentStarColor = Color.FromArgb(58,182,255);

    public MainForm()
    {
        Text = "illumium flux orbaratum";
        Width = 1200; Height = 760;
        MinimumSize = new Size(800, 500);
        BackColor = Color.White;
        ForeColor = Color.FromArgb(23,23,26);
        Font = new Font("Consolas", 10f);
        StartPosition = FormStartPosition.CenterScreen;

        var top = new Panel { Dock=DockStyle.Top, Height=54, BackColor=Color.White };
        top.Paint += (_, e) => { using var p = new Pen(Color.FromArgb(215,215,210)); e.Graphics.DrawLine(p,0,53,top.Width,53); };

        var brand = new Label {
            Text="●  illumium flux orbaratum shell",
            AutoSize=true, Left=18, Top=17, Font=new Font("Consolas",11,FontStyle.Bold)
        };
        top.Controls.Add(brand);

        back.Text="back"; back.FlatStyle=FlatStyle.Flat; back.FlatAppearance.BorderSize=0;
        back.SetBounds(430,11,65,30); back.Click += (_,_) => GoBack(); top.Controls.Add(back);

        choose.Text="browse"; choose.FlatStyle=FlatStyle.Flat; choose.FlatAppearance.BorderSize=0;
        choose.SetBounds(500,11,75,30); choose.Click += (_,_) => ChooseFolder(); top.Controls.Add(choose);

        pathLabel.AutoSize=true; pathLabel.Anchor=AnchorStyles.Top|AnchorStyles.Right;
        pathLabel.Top=18; pathLabel.Left=610;
        top.Controls.Add(pathLabel);

        resourceLabel.AutoSize=true; resourceLabel.Anchor=AnchorStyles.Top|AnchorStyles.Right;
        resourceLabel.Top=18; resourceLabel.Left=900;
        top.Controls.Add(resourceLabel);

        Controls.Add(canvas);
        Controls.Add(top);
        canvas.Dock=DockStyle.Fill;

        canvas.OrbActivated += OpenOrb;
        canvas.OrbContext += ContextOrb;

        Shown += (_,_) => { Navigate(currentPath, false); StartMonitoring(); };
        Resize += (_,_) => canvas.Relayout();
    }

    void StartMonitoring()
    {
        resourceTimer.Tick += (_,_) => {
            cpu = ReadCpu();
            ram = ReadRam();
            disk = ReadDisk();
            securityVulnerability = ReadSecurityVulnerability();

            // Persistent colour is based ONLY on total HDD/SSD space usage.
            // Blue: under 50% used. Orange: 50%+ used. Red: 10% or less remaining.
            persistentStarColor = disk >= 90f
                ? Color.FromArgb(255,90,90)
                : disk >= 50f
                    ? Color.FromArgb(255,153,51)
                    : Color.FromArgb(58,182,255);

            temporaryAlert = securityVulnerability || cpu >= 98f || ram >= 98f;
            ApplyStarState();
            resourceLabel.Text = $"cpu {cpu:0}%   ram {ram:0}%   disk {disk:0}%" +
                                  (securityVulnerability ? "   SECURITY ALERT" : "");
            resourceLabel.ForeColor = canvas.StarColor;
            canvas.Invalidate();
        };

        alertFlashTimer.Tick += (_,_) => {
            alertFlashOn = !alertFlashOn;
            ApplyStarState();
            canvas.Invalidate();
        };

        resourceTimer.Start();
        alertFlashTimer.Start();
    }

    void Navigate(string path, bool remember=true)
    {
        try {
            path = Path.GetFullPath(path);
            if (!Directory.Exists(path)) return;
            if (remember && Directory.Exists(currentPath)) history.Push(currentPath);
            currentPath = path;
            pathLabel.Text = "flux:" + path;
            canvas.LoadDirectory(path);
        } catch (Exception ex) { MessageBox.Show(ex.Message, "illumium flux"); }
    }

    void GoBack()
    {
        if (history.Count > 0) Navigate(history.Pop(), false);
    }

    void ChooseFolder()
    {
        using var d = new FolderBrowserDialog { Description="choose an orbaratum to render" };
        if (d.ShowDialog(this)==DialogResult.OK) { history.Clear(); Navigate(d.SelectedPath, false); }
    }

    void OpenOrb(OrbItem o)
    {
        if (o.IsFolder) Navigate(o.FullPath);
        else Launch(o.FullPath);
    }

    void Launch(string path)
    {
        try {
            Process.Start(new ProcessStartInfo(path) { UseShellExecute=true });
        } catch {
            try { Process.Start(new ProcessStartInfo("cmd.exe",$"/c start \"\" \"{path}\"") { UseShellExecute=false, CreateNoWindow=true }); }
            catch(Exception ex) { MessageBox.Show(ex.Message,"illumium flux"); }
        }
    }

    void ContextOrb(OrbItem o, Point screen)
    {
        var m = new ContextMenuStrip();
        m.Items.Add(o.IsFolder ? "enter" : "open", null, (_,_) => OpenOrb(o));
        m.Items.Add("properties", null, (_,_) => ShowProperties(o));
        if (!o.IsFolder) m.Items.Add("run program", null, (_,_) => Launch(o.FullPath));
        m.Items.Add(new ToolStripSeparator());
        m.Items.Add("browse", null, (_,_) => Navigate(o.IsFolder ? o.FullPath : Path.GetDirectoryName(o.FullPath)!));
        m.Show(screen);
    }

    void ShowProperties(OrbItem o)
    {
        var info = o.IsFolder ? "orbaratum (folder)" : "orb (file)";
        var size = o.IsFolder ? $"{Directory.EnumerateFileSystemEntries(o.FullPath).Count()} items" : $"{new FileInfo(o.FullPath).Length / 1024.0:0.0} KB";
        MessageBox.Show($"name: {o.Name}\r\nkind: {info}\r\ntag: {o.Prefix}\r\nsize: {size}\r\nmodified: {o.Modified:g}",
            "illumium flux // properties");
    }

    static float ReadRam()
    {
        try {
            using var s = new PerformanceCounter("Memory","% Committed Bytes In Use");
            s.NextValue(); System.Threading.Thread.Sleep(30);
            return s.NextValue();
        } catch { return 0; }
    }

    static float ReadCpu()
    {
        try {
            using var s = new PerformanceCounter("Processor","% Processor Time","_Total");
            s.NextValue(); System.Threading.Thread.Sleep(80);
            return s.NextValue();
        } catch { return 0; }
    }

    float ReadDisk()
    {
        try {
            var d = new DriveInfo(Path.GetPathRoot(currentPath)!);
            return 100f - ((float)d.AvailableFreeSpace / d.TotalSize * 100f);
        } catch { return 0; }
    }

    static bool ReadSecurityVulnerability()
    {
        // Uses Windows Defender status when available. A disabled Defender
        // antivirus or real-time protection state is treated as a security alert.
        // This is intentionally conservative: it does not claim that every
        // security weakness on the PC has been detected.
        try {
            using var p = new Process();
            p.StartInfo = new ProcessStartInfo {
                FileName = "powershell.exe",
                Arguments = "-NoProfile -NonInteractive -Command \"$s=Get-MpComputerStatus; if($s){ [Console]::Write(\"$($s.AntivirusEnabled)|$($s.RealTimeProtectionEnabled)\") }\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };
            p.Start();
            string output = p.StandardOutput.ReadToEnd().Trim();
            p.WaitForExit(700);
            var parts = output.Split('|');
            if (parts.Length == 2)
                return string.Equals(parts[0], "False", StringComparison.OrdinalIgnoreCase) ||
                       string.Equals(parts[1], "False", StringComparison.OrdinalIgnoreCase);
        } catch { }
        return false;
    }

    void ApplyStarState()
    {
        // Temporary alerts flash red regardless of the persistent storage colour.
        canvas.StarColor = temporaryAlert && alertFlashOn
            ? Color.FromArgb(255,90,90)
            : persistentStarColor;
    }
}

public sealed class OrbItem
{
    public string FullPath="", Name="", Prefix="", Extension="";
    public bool IsFolder;
    public DateTime Modified;
    public float Age;
    public long SizeBytes;
}

public sealed class OrbCanvas : Control
{
    public event Action<OrbItem>? OrbActivated;
    public event Action<OrbItem,Point>? OrbContext;
    public Color StarColor = Color.FromArgb(58,182,255);

    // Java-style field behavior: keep the whole directory, but show only a readable
    // number of entities in one viewport and move through the larger field by scrolling.
    const int TargetBuisPerViewport = 15;
    const int ColumnsPerField = 5;
    const int RowsPerField = 3;
    const int HorizontalFieldGap = 90;
    const float ScrollPixelsPerTick = 34f;
    const float IndicatorHeight = 92f;

    readonly List<OrbItem> items = new();
    readonly List<(OrbItem item, PointF p, float r)> orbs = new();
    readonly List<PointF> virtualStars = new();
    readonly List<int> clusterStarts = new();
    readonly List<int> clusterEnds = new();
    readonly Random rng = new(7);
    readonly System.Windows.Forms.Timer scrollTimer = new() { Interval=16 };

    string currentPath="";
    float scrollOffset;
    float targetScrollOffset;
    float scrollStartOffset;
    float scrollAnimation;
    int scrollDirection;
    bool scrolling;

    public OrbCanvas()
    {
        DoubleBuffered=true;
        BackColor=Color.White;
        TabStop=true;

        MouseDoubleClick += (_,e) => {
            var hit=Hit(e.Location);
            if(hit.item!=null) OrbActivated?.Invoke(hit.item);
        };
        MouseClick += (_,e) => {
            if(e.Button==MouseButtons.Right) {
                var hit=Hit(e.Location);
                if(hit.item!=null) OrbContext?.Invoke(hit.item, PointToScreen(e.Location));
            }
        };
        MouseWheel += (_,e) => {
            if(items.Count <= TargetBuisPerViewport) return;
            if(e.Delta < 0) BeginScroll(+1);
            else if(e.Delta > 0) BeginScroll(-1);
        };
        scrollTimer.Tick += (_,_) => AnimateScroll();
    }

    public void LoadDirectory(string path)
    {
        currentPath=path;
        items.Clear();
        orbs.Clear();
        virtualStars.Clear();
        scrollOffset=0;
        targetScrollOffset=0;
        scrolling=false;

        try {
            foreach(var d in Directory.EnumerateDirectories(path).OrderBy(d => Path.GetFileName(d), StringComparer.OrdinalIgnoreCase))
                items.Add(Make(d,true));
            foreach(var f in Directory.EnumerateFiles(path).OrderBy(d => Path.GetFileName(d), StringComparer.OrdinalIgnoreCase))
                items.Add(Make(f,false));
        } catch { }

        BuildVirtualField();
        Relayout();
        _ = PopulateDirectorySizesAsync();
    }

    async Task PopulateDirectorySizesAsync()
    {
        var snapshot=items.ToArray();
        await Task.Run(() => {
            foreach(var item in snapshot) {
                try {
                    item.SizeBytes = item.IsFolder ? GetDirectorySize(item.FullPath) : new FileInfo(item.FullPath).Length;
                } catch { item.SizeBytes = 0; }
            }
        });
        if(IsDisposed || Disposing) return;
        if(InvokeRequired) BeginInvoke(new Action(() => { BuildVirtualField(); Relayout(); }));
        else { BuildVirtualField(); Relayout(); }
    }

    static long GetDirectorySize(string path)
    {
        long total=0;
        try {
            foreach(var file in Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories)) {
                try { total += new FileInfo(file).Length; } catch { }
            }
        } catch { }
        return total;
    }

    OrbItem Make(string p,bool folder)
    {
        var n=Path.GetFileName(p);
        var ext=folder ? "" : Path.GetExtension(p).TrimStart('.').ToLowerInvariant();
        var fi=folder ? null : new FileInfo(p);
        var mod=folder ? Directory.GetLastWriteTime(p) : fi!.LastWriteTime;
        var days=(DateTime.Now-mod).TotalDays;
        var age=(float)Math.Max(0,Math.Min(1,1-days/3650));
        var prefix=folder ? "verse ~ " : (string.IsNullOrWhiteSpace(ext) ? "file - " : ext+" - ");
        return new OrbItem{FullPath=p,Name=n,Prefix=prefix,Extension=ext,IsFolder=folder,Modified=mod,Age=age};
    }

    float Radius(OrbItem o)
    {
        if(items.Count==0) return 48f;

        // Size is relative to the other entries in the CURRENT directory.
        // Log scaling keeps a huge folder from swallowing the whole field while
        // still making meaningful differences visible.
        long maxSize=1;
        foreach(var item in items) maxSize=Math.Max(maxSize, item.SizeBytes);

        double value=Math.Max(1L,o.SizeBytes);
        double maxLog=Math.Log10(maxSize+1d);
        double normalized=maxLog<=0 ? 0 : Math.Log10(value+1d)/maxLog;
        normalized=Math.Clamp(normalized,0d,1d);

        // v6 folder radius was 48px. Keep the new range within the requested
        // 1.5x-smaller to 2.5x-larger envelope: 32px .. 120px.
        const float MinRadius=32f;
        const float MaxRadius=120f;
        float shaped=(float)Math.Pow(normalized,0.58);
        return MinRadius+(MaxRadius-MinRadius)*shaped;
    }

    void BuildVirtualField()
    {
        virtualStars.Clear();
        clusterStarts.Clear();
        clusterEnds.Clear();
        if(items.Count==0) return;

        // Fifteen remains a viewport-density target, not a data limit. Within each
        // field/page the entities are deliberately separated into visual clusters.
        // The normal 15-node field is grouped as 5 + 3 + 6 + 1, while a shorter
        // final field simply truncates that pattern to its actual cardinality.
        float fieldWidth=Math.Max(Width,980);
        // Each page gets a slightly different horizontal rhythm so the clusters do
        // not land on the same rigid x coordinates from page to page.
        float segmentWidth=fieldWidth+HorizontalFieldGap+rng.Next(-35,36);
        float clusterGap=35f+rng.NextSingle()*90f;
        float left=88f;
        float top=100f;
        float usableW=Math.Max(720,fieldWidth-176);
        float usableH=Math.Max(270,Height-IndicatorHeight-120);
        int pageCount=Math.Max(1,(items.Count+TargetBuisPerViewport-1)/TargetBuisPerViewport);

        int index=0;
        for(int page=0; page<pageCount; page++) {
            int pageCountItems=Math.Min(TargetBuisPerViewport,items.Count-index);
            int[] pattern={5,3,6,1};
            int pageLocal=0;
            int clusterNumber=0;

            while(pageLocal<pageCountItems) {
                int clusterSize=Math.Min(pattern[clusterNumber%pattern.Length],pageCountItems-pageLocal);
                int clusterStart=index+pageLocal;
                int clusterEnd=clusterStart+clusterSize;
                clusterStarts.Add(clusterStart);
                clusterEnds.Add(clusterEnd);

                // Give every cluster its own spatial island. The standard 15-node
                // field is 5 + 3 + 6 + 1, so the eye can immediately read separate
                // groups instead of one undifferentiated cloud.
                int slot=clusterNumber%4;
                float[] slotCenters={0.14f,0.46f,0.80f,0.54f};
                // Deliberate horizontal drift inside every cluster, plus a different
                // cluster offset on every page. This produces the looser, organic
                // spacing seen in the reference instead of a fixed grid.
                float pageJitter=MathF.Sin((page+1)*1.37f+(clusterNumber+1)*0.71f)*62f;
                float localJitter=(rng.NextSingle()-0.5f)*70f;
                float centerX=left+usableW*slotCenters[slot]+pageJitter+localJitter;
                float clusterWidth=(slot==1?235f:(slot==3?145f:275f));
                clusterWidth += clusterGap*.35f;
                // Keep enough horizontal room for the largest orb in this cluster.
                // A 95px cluster cannot contain a 48px-radius folder with margins.
                float clusterMaxRadius=0f;
                for(int k=0;k<clusterSize;k++)
                    clusterMaxRadius=Math.Max(clusterMaxRadius,Radius(items[clusterStart+k]));
                clusterWidth=Math.Max(clusterWidth,clusterMaxRadius*2f+16f);
                int cols=clusterSize<=3 ? clusterSize : 3;
                int rows=(int)Math.Ceiling(clusterSize/(float)Math.Max(1,cols));
                float cStepX=cols<=1 ? 0 : clusterWidth/(cols-1);
                float cStepY=rows<=1 ? 0 : Math.Min(92f,usableH/(rows-1));
                float centerY=top+usableH*(slot==3?0.79f:0.48f);

                // Nebula-like placement: retain each cluster's spatial identity,
                // but randomize the positions so no two stars share the same Y level.
                // A minimum vertical separation also keeps large orbs from feeling
                // mechanically stacked.
                var usedY=new List<float>();
                float minY=Math.Max(58f,centerY-usableH*.34f);
                float maxY=Math.Min(usableH+top-35f,centerY+usableH*.34f);
                for(int j=0;j<clusterSize;j++) {
                    float r=Radius(items[clusterStart+j]);
                    float xMin=centerX-clusterWidth/2f+r+4f;
                    float xMax=centerX+clusterWidth/2f-r-4f;
                    float yMin=minY+r+4f;
                    float yMax=maxY-r-4f;
                    float y;
                    int attempts=0;
                    do {
                        y=yMin+(yMax-yMin)*rng.NextSingle();
                        attempts++;
                    } while(usedY.Any(v=>Math.Abs(v-y)<Math.Max(28f,r*.85f)) && attempts<80);
                    usedY.Add(y);

                    float x=xMin+(xMax-xMin)*rng.NextSingle();
                    // Slight deterministic drift gives the field a natural current
                    // without allowing objects to overlap excessively.
                    x += MathF.Sin((j+1)*1.73f+page*.91f)*Math.Min(18f,Math.Max(6f,(xMax-xMin)*.08f));
                    x=Math.Clamp(x,xMin,xMax);
                    virtualStars.Add(new PointF(x+page*segmentWidth,y));
                }

                pageLocal+=clusterSize;
                clusterNumber++;
            }
            index+=pageCountItems;
        }
    }

    public void Relayout()
    {
        if(items.Count==0){ Invalidate(); return; }
        BuildVirtualField();
        scrollOffset=Math.Clamp(scrollOffset,0,MaxScrollOffset());
        targetScrollOffset=Math.Clamp(targetScrollOffset,0,MaxScrollOffset());
        RebuildVisibleOrbs();
        Invalidate();
    }

    float MaxScrollOffset()
    {
        if(items.Count<=TargetBuisPerViewport) return 0;
        int pages=(items.Count+TargetBuisPerViewport-1)/TargetBuisPerViewport;
        float segmentWidth=Math.Max(Width,980)+HorizontalFieldGap;
        return Math.Max(0,pages*segmentWidth-Width-HorizontalFieldGap);
    }

    void RebuildVisibleOrbs()
    {
        orbs.Clear();
        if(items.Count==0 || virtualStars.Count!=items.Count) return;

        RectangleF viewport=new(0,0,Width,Math.Max(1,Height-IndicatorHeight));
        for(int i=0;i<items.Count;i++) {
            var item=items[i];
            var p=new PointF(virtualStars[i].X-scrollOffset,virtualStars[i].Y);
            float r=Radius(item);
            if(p.X+r < -100 || p.X-r > Width+100 || p.Y+r < 45 || p.Y-r > viewport.Bottom) continue;
            orbs.Add((item,p,r));
        }
    }

    void BeginScroll(int direction)
    {
        if(items.Count<=TargetBuisPerViewport) return;
        float segmentWidth=Math.Max(Width,980)+HorizontalFieldGap;
        float desired=targetScrollOffset + direction*segmentWidth;
        desired=Math.Clamp(desired,0,MaxScrollOffset());
        if(Math.Abs(desired-targetScrollOffset)<1) return;

        scrollStartOffset=scrollOffset;
        targetScrollOffset=desired;
        scrollDirection=direction;
        scrollAnimation=0;
        scrolling=true;
        scrollTimer.Start();
        Focus();
    }

    void AnimateScroll()
    {
        scrollAnimation=Math.Min(1f,scrollAnimation+.095f);
        // Smoothstep gives the same deliberate, animated field movement rather than
        // an abrupt page swap.
        float t=scrollAnimation*scrollAnimation*(3f-2f*scrollAnimation);
        scrollOffset=scrollStartOffset+(targetScrollOffset-scrollStartOffset)*t;
        RebuildVisibleOrbs();
        Invalidate();
        if(scrollAnimation>=1f) {
            scrollOffset=targetScrollOffset;
            scrolling=false;
            scrollTimer.Stop();
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
        e.Graphics.TextRenderingHint=System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        // Paint in layers: orb bodies first, connectors next, then ALL names last.
        // This keeps every orbaratum/file name in the foreground even when orbs
        // overlap one another or a connector passes through the label area.
        foreach(var a in orbs) DrawOrb(e.Graphics,a);
        DrawConnectors(e.Graphics);
        foreach(var a in orbs) DrawOrbLabel(e.Graphics,a);
        DrawDirectoryIndicator(e.Graphics);
    }

    void DrawConnectors(Graphics g)
    {
        if(items.Count<2 || virtualStars.Count!=items.Count) return;

        using var pen=new Pen(Color.FromArgb(115,50,50,50),1f) { DashStyle=DashStyle.Custom, DashPattern=new float[] { 1f, 5f } };
        using var glow=new Pen(Color.FromArgb(28,StarColor),2f) { DashStyle=DashStyle.Custom, DashPattern=new float[] { 1f, 5f } };

        // The Java field generates one connector between successive BUI entities.
        // Here the connector is explicitly star-to-star, so the orb aura never hides
        // the actual relationship point.
        for(int i=0;i<items.Count-1;i++) {
            PointF a=new(virtualStars[i].X-scrollOffset,virtualStars[i].Y);
            PointF b=new(virtualStars[i+1].X-scrollOffset,virtualStars[i+1].Y);
            if(!LineIntersectsViewport(a,b)) continue;
            g.DrawLine(glow,a,b);
            g.DrawLine(pen,a,b);
        }
    }

    bool LineIntersectsViewport(PointF a,PointF b)
    {
        var rect=new RectangleF(-10,35,Width+20,Math.Max(1,Height-IndicatorHeight-35));
        return rect.Contains(a) || rect.Contains(b) ||
               SegmentMayCross(a,b,rect.Left,rect.Top,rect.Right,rect.Bottom);
    }

    static bool SegmentMayCross(PointF a,PointF b,float l,float t,float r,float bot)
    {
        float minX=Math.Min(a.X,b.X), maxX=Math.Max(a.X,b.X);
        float minY=Math.Min(a.Y,b.Y), maxY=Math.Max(a.Y,b.Y);
        return maxX>=l && minX<=r && maxY>=t && minY<=bot;
    }

    float StarAgeLevel(OrbItem item)
    {
        if(items.Count==0) return 0.5f;
        float min=items.Min(x=>x.Age);
        float max=items.Max(x=>x.Age);
        if(max-min<0.0001f) return 0.5f;
        return Math.Clamp((item.Age-min)/(max-min),0f,1f);
    }

    void DrawOrb(Graphics g,(OrbItem item,PointF p,float r) a)
    {
        var o=a.item;
        var rect=new RectangleF(a.p.X-a.r,a.p.Y-a.r,a.r*2,a.r*2);
        using var path=new GraphicsPath();
        path.AddEllipse(rect);
        // Keep the orb itself hollow/transparent at the centre. The star remains
        // fully responsible for the luminous core, while the orb is only its
        // surrounding gradient/aura.
        using var brush=new PathGradientBrush(path) {
            CenterPoint=a.p,
            CenterColor=Color.FromArgb(0, o.IsFolder ? Color.White : Color.Black),
            SurroundColors=new[]{o.IsFolder ? Color.FromArgb(210,210,206) : Color.FromArgb(65,65,65)}
        };
        g.FillEllipse(brush,rect);

        // Java's age reflection is a glow property, not a separate ring. The star
        // is a gradient core whose intensity is relative to the other entities in
        // this field. Its physical maximum is 1/8 inch at the current device DPI.
        float age=StarAgeLevel(o);
        float maxStarDiameter=Math.Max(1f,g.DpiX/8f);
        float starDiameter=Math.Max(4f,Math.Min(maxStarDiameter,maxStarDiameter*(0.28f+0.72f*age)));
        float half=starDiameter/2f;

        // Circular neon core: no literal star points and no surrounding ring.
        using var starPath=new GraphicsPath();
        starPath.AddEllipse(new RectangleF(a.p.X-half,a.p.Y-half,starDiameter,starDiameter));
        int coreAlpha=(int)(145+110*age);
        int edgeAlpha=(int)(25+100*age);
        using var starBrush=new PathGradientBrush(starPath) {
            CenterPoint=a.p,
            CenterColor=Color.FromArgb(coreAlpha,StarColor),
            SurroundColors=new[]{Color.FromArgb(edgeAlpha,StarColor)}
        };
        g.FillPath(starBrush,starPath);
    }

    void DrawOrbLabel(Graphics g,(OrbItem item,PointF p,float r) a)
    {
        var o=a.item;
        // Labels remain geometrically inside their own orb, but are painted after
        // every orb and connector so they can never become trapped underneath
        // another overlapping orb.
        string displayName=o.Name;
        float fontSize=9.5f;
        float maxTextWidth=Math.Max(24f,a.r*1.72f);
        string shown=o.Prefix+displayName;
        while(shown.Length>4) {
            using var probe=new Font("Consolas",fontSize,FontStyle.Regular);
            if(g.MeasureString(shown,probe).Width<=maxTextWidth) break;
            if(fontSize>6.5f) { fontSize-=0.5f; continue; }
            shown=shown.Substring(0,shown.Length-1);
        }
        if(shown.Length<o.Prefix.Length) shown=o.Prefix;
        using var font=new Font("Consolas",fontSize,FontStyle.Regular);
        using var pfxBrush=new SolidBrush(StarColor);
        using var nameBrush=new SolidBrush(Color.FromArgb(88,88,92));
        string labelName=shown.StartsWith(o.Prefix,StringComparison.Ordinal)
            ? shown.Substring(o.Prefix.Length) : shown;
        float prefixW=g.MeasureString(o.Prefix,font).Width;
        float nameW=g.MeasureString(labelName,font).Width;
        float totalW=prefixW+nameW;
        float tx=a.p.X-totalW/2f;
        float ty=a.p.Y-font.Height/2f;
        g.DrawString(o.Prefix,font,pfxBrush,tx,ty);
        g.DrawString(labelName,font,nameBrush,tx+prefixW,ty);
    }

    void DrawDirectoryIndicator(Graphics g)
    {
        float y=Height-IndicatorHeight+12;
        string display=DirectoryDisplayText();
        using var font=new Font("Consolas",9.5f,FontStyle.Regular);
        SizeF size=g.MeasureString(display,font);
        float center=Width/2f;
        using var textBrush=new SolidBrush(Color.FromArgb(80,80,84));
        using var coreBrush=new SolidBrush(StarColor);
        using var smallBrush=new SolidBrush(Color.FromArgb(85,StarColor));

        g.DrawString(display,font,textBrush,center-size.Width/2f,y);

        float pairY=y+46;
        float leftX=center-10;
        float rightX=center+20;
        float maxScroll=MaxScrollOffset();
        // One monotonic transfer across the entire field: page 1 = left maximum /
        // right minimum, middle = equal, final page = right maximum / left minimum.
        // There is no wraparound or alternating behavior.
        float transfer=maxScroll<=0 ? 0f : Math.Clamp(scrollOffset/maxScroll,0f,1f);
        float leftR=16f-12f*transfer;
        float rightR=4f+12f*transfer;

        // Java-inspired adjacent pair: the left core begins dominant; scrolling
        // transfers dominance to the neighboring right core while the pair stays together.
        using var leftGlow=new Pen(Color.FromArgb(90,StarColor),1.5f);
        using var rightGlow=new Pen(Color.FromArgb(65,StarColor),1.5f);
        g.FillEllipse(coreBrush,leftX-leftR,pairY-leftR,leftR*2,leftR*2);
        g.DrawEllipse(leftGlow,leftX-leftR-2,pairY-leftR-2,(leftR+2)*2,(leftR+2)*2);
        g.FillEllipse(smallBrush,rightX-rightR,pairY-rightR,rightR*2,rightR*2);
        g.DrawEllipse(rightGlow,rightX-rightR-2,pairY-rightR-2,(rightR+2)*2,(rightR+2)*2);
    }

    string DirectoryDisplayText()
    {
        string relative=currentPath;
        try {
            var root=Path.GetPathRoot(currentPath) ?? "";
            if(relative.StartsWith(root,StringComparison.OrdinalIgnoreCase))
                relative=relative[root.Length..].TrimStart(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
        } catch { }
        relative=relative.Replace(Path.DirectorySeparatorChar,'/').Replace(Path.AltDirectorySeparatorChar,'/');
        string core="core:"+(relative.Length==0?"/": "/"+relative+"/");

        int total=items.Count;
        int start=total==0?0:Math.Min(total-1,(int)Math.Floor(scrollOffset/Math.Max(1,Math.Max(Width,980)+HorizontalFieldGap))*TargetBuisPerViewport);
        int end=total==0?0:Math.Min(total,start+TargetBuisPerViewport);
        return total>TargetBuisPerViewport ? $"{core}   [{start+1:00}-{end:00} / {total}]" : core;
    }

    (OrbItem? item,float dist) Hit(Point p)
    {
        OrbItem? best=null; float dBest=float.MaxValue;
        foreach(var a in orbs) {
            var d=Distance(p,a.p);
            if(d<=a.r && d<dBest){best=a.item;dBest=d;}
        }
        return(best,dBest);
    }

    static float Distance(PointF a,PointF b)=>MathF.Sqrt((a.X-b.X)*(a.X-b.X)+(a.Y-b.Y)*(a.Y-b.Y));
}
